package com.imperialreader.data.download

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.documentfile.provider.DocumentFile
import com.imperialreader.data.db.ChapterEntity
import com.imperialreader.data.db.MangaEntity
import com.imperialreader.data.book.BookSources
import com.imperialreader.data.book.NovelChapterEpub
import com.imperialreader.data.source.SChapter
import com.imperialreader.data.source.MangaFirePageTransform
import com.imperialreader.data.source.SManga
import com.imperialreader.util.app
import com.imperialreader.util.mimeForExt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.Call
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger

data class DownloadQueueItem(
    val taskKey: String,
    val mangaId: Long?,
    val mangaTitle: String,
    val chapterId: Long?,
    val chapterName: String,
    val progress: Int,
    val downloading: Boolean,
    val paused: Boolean = false
)

/**
 * Sequential chapter download queue (3 pages in parallel per chapter).
 * Progress is exposed per chapter id (0..100), with a separate ordered snapshot for the More tab.
 * The queue lives in memory; chapters that finished are flagged `downloaded` in the database.
 */
class DownloadManager(private val ctx: Context) {

    private data class Task(val manga: MangaEntity, val chapter: ChapterEntity)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val queue = ArrayDeque<Task>()
    private var worker: Job? = null
    private var activeTask: Task? = null
    private val externalTasks = LinkedHashMap<String, DownloadQueueItem>()
    private val pausedChapterIds = mutableSetOf<Long>()
    private val pauseGates = mutableMapOf<Long, CompletableDeferred<Unit>>()
    private val cancelledChapterIds = mutableSetOf<Long>()
    private val activeCalls = mutableMapOf<Long, MutableSet<Call>>()

    private val _progress = MutableStateFlow<Map<Long, Int>>(emptyMap())
    val progress: StateFlow<Map<Long, Int>> = _progress

    private val _queueItems = MutableStateFlow<List<DownloadQueueItem>>(emptyList())
    val queueItems: StateFlow<List<DownloadQueueItem>> = _queueItems

    private val _errors = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val errors: SharedFlow<String> = _errors

    @Synchronized
    private fun setProgress(id: Long, value: Int?) {
        _progress.value = if (value == null) _progress.value - id else _progress.value + (id to value)
        publishQueueLocked()
    }

    /** Called under this manager's monitor. */
    private fun publishQueueLocked() {
        val values = _progress.value
        val items = buildList {
            activeTask?.let { task ->
                add(
                    DownloadQueueItem(
                        "chapter:${task.chapter.id}", task.manga.id, task.manga.title, task.chapter.id, task.chapter.name,
                        values[task.chapter.id] ?: 0, downloading = true,
                        paused = task.chapter.id in pausedChapterIds
                    )
                )
            }
            queue.forEach { task ->
                add(
                    DownloadQueueItem(
                        "chapter:${task.chapter.id}", task.manga.id, task.manga.title, task.chapter.id, task.chapter.name,
                        values[task.chapter.id] ?: 0, downloading = false,
                        paused = task.chapter.id in pausedChapterIds
                    )
                )
            }
            addAll(externalTasks.values)
        }
        _queueItems.value = items
    }

    /** Adds or updates a non-chapter-manager download (currently EPUB/catalog downloads). */
    @Synchronized
    fun reportExternalDownload(
        taskKey: String,
        title: String,
        detail: String,
        progress: Int = 0
    ) {
        externalTasks[taskKey] = DownloadQueueItem(
            taskKey = taskKey,
            mangaId = null,
            mangaTitle = title,
            chapterId = null,
            chapterName = detail,
            progress = progress.coerceIn(0, 100),
            downloading = true
        )
        publishQueueLocked()
    }

    @Synchronized
    fun removeExternalDownload(taskKey: String) {
        externalTasks.remove(taskKey)
        publishQueueLocked()
    }

    @Synchronized
    fun enqueue(manga: MangaEntity, chapters: List<ChapterEntity>) {
        for (c in chapters) {
            if (c.downloaded || _progress.value.containsKey(c.id)) continue
            queue.addLast(Task(manga, c))
            setProgress(c.id, 0)
        }
        startWorker()
    }

    fun pauseChapter(chapterId: Long) {
        synchronized(this) {
            if (activeTask?.chapter?.id != chapterId && queue.none { it.chapter.id == chapterId }) return
            pausedChapterIds += chapterId
            pauseGates.getOrPut(chapterId) { CompletableDeferred() }
            publishQueueLocked()
        }
    }

    fun resumeChapter(chapterId: Long) {
        synchronized(this) {
            pausedChapterIds -= chapterId
            pauseGates.remove(chapterId)?.complete(Unit)
            publishQueueLocked()
        }
    }

    fun cancelChapter(chapterId: Long) {
        val calls = synchronized(this) {
            val removedQueued = queue.removeAll { it.chapter.id == chapterId }
            val isActive = activeTask?.chapter?.id == chapterId
            if (!removedQueued && !isActive) return
            if (isActive) cancelledChapterIds += chapterId
            else _progress.value = _progress.value - chapterId
            pausedChapterIds -= chapterId
            pauseGates.remove(chapterId)?.complete(Unit)
            publishQueueLocked()
            if (isActive) activeCalls[chapterId]?.toList().orEmpty() else emptyList()
        }
        calls.forEach(Call::cancel)
    }

    fun cancelAllForManga(mangaId: Long) {
        val calls = synchronized(this) {
            val queuedIds = queue.filter { it.manga.id == mangaId }.map { it.chapter.id }
            queue.removeAll { it.manga.id == mangaId }
            queuedIds.forEach { id ->
                _progress.value = _progress.value - id
                pausedChapterIds -= id
                pauseGates.remove(id)?.complete(Unit)
            }
            val active = activeTask?.takeIf { it.manga.id == mangaId }
            if (active != null) {
                val id = active.chapter.id
                cancelledChapterIds += id
                pausedChapterIds -= id
                pauseGates.remove(id)?.complete(Unit)
            }
            publishQueueLocked()
            active?.let { activeCalls[it.chapter.id]?.toList().orEmpty() }.orEmpty()
        }
        calls.forEach(Call::cancel)
    }

    @Synchronized
    private fun startWorker() {
        if (worker?.isActive == true) return
        if (queue.isEmpty()) return
        DownloadService.start(ctx)
        worker = scope.launch {
            try {
                while (true) {
                    val task = synchronized(this@DownloadManager) {
                        queue.removeFirstOrNull().also {
                            activeTask = it
                            publishQueueLocked()
                        }
                    } ?: break
                    try {
                        awaitIfResumed(task.chapter.id)
                        download(task)
                    } catch (e: CancellationException) {
                        val userCancelled = synchronized(this@DownloadManager) {
                            task.chapter.id in cancelledChapterIds
                        }
                        if (!userCancelled) throw e
                        ctx.app.storage.deleteDownload(task.manga, task.chapter)
                    } catch (e: Exception) {
                        ctx.app.storage.deleteDownload(task.manga, task.chapter)
                        _errors.tryEmit("Download failed: ${task.chapter.name} (${e.message})")
                    } finally {
                        synchronized(this@DownloadManager) {
                            _progress.value = _progress.value - task.chapter.id
                            if (activeTask?.chapter?.id == task.chapter.id) activeTask = null
                            cancelledChapterIds -= task.chapter.id
                            pausedChapterIds -= task.chapter.id
                            pauseGates.remove(task.chapter.id)?.complete(Unit)
                            publishQueueLocked()
                        }
                    }
                }
            } finally {
                DownloadService.stop(ctx)
                synchronized(this@DownloadManager) {
                    worker = null
                    if (queue.isNotEmpty()) startWorker()
                }
            }
        }
    }

    private suspend fun download(task: Task) {
        val app = ctx.app
        awaitIfResumed(task.chapter.id)
        if (BookSources.get(task.manga.source)?.isWebNovel == true) {
            NovelChapterEpub.download(ctx, task.manga, task.chapter)
            app.db.chapterDao().setDownloaded(task.chapter.id, true)
            return
        }
        val source = app.sources.get(task.manga.source) ?: throw IOException("Source not available")
        val loaded = source.loadPages(
            SManga(url = task.manga.url, title = task.manga.title),
            SChapter(url = task.chapter.url, name = task.chapter.name)
        )
        val pages = loaded.urls
        if (pages.isEmpty()) throw IOException("No pages found")
        val dir = app.storage.chapterDir(task.manga, task.chapter, create = true)
            ?: throw IOException("Cannot create download folder")
        dir.listFiles().forEach { it.delete() }

        val done = AtomicInteger(0)
        val sem = Semaphore(3)
        coroutineScope {
            pages.mapIndexed { index, url ->
                async {
                    awaitIfResumed(task.chapter.id)
                    sem.withPermit {
                        awaitIfResumed(task.chapter.id)
                        downloadPage(task.chapter.id, loaded.headers, url, index, dir)
                        setProgress(task.chapter.id, done.incrementAndGet() * 100 / pages.size)
                    }
                }
            }.awaitAll()
        }
        app.db.chapterDao().setDownloaded(task.chapter.id, true)
    }

    private suspend fun downloadPage(
        chapterId: Long,
        headers: Map<String, String>,
        url: String,
        index: Int,
        dir: DocumentFile
    ) {
        var lastError: Exception? = null
        for (attempt in 0 until 3) {
            awaitIfResumed(chapterId)
            var created: DocumentFile? = null
            var call: Call? = null
            try {
                val request = Request.Builder().url(url).apply {
                    headers.forEach { (k, v) -> header(k, v) }
                }.build()
                call = ctx.app.network.client.newCall(request)
                synchronized(this) { activeCalls.getOrPut(chapterId) { mutableSetOf() }.add(call) }
                call.execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                    val ct = resp.header("Content-Type").orEmpty()
                    val scrambleOffset = MangaFirePageTransform.offset(url)
                    val ext = if (scrambleOffset != null) "jpg" else when {
                        "png" in ct -> "png"
                        "webp" in ct -> "webp"
                        "gif" in ct -> "gif"
                        "avif" in ct -> "avif"
                        else -> "jpg"
                    }
                    val file = dir.createFile(mimeForExt(ext), "%03d.%s".format(index + 1, ext))
                        ?: throw IOException("Cannot create file")
                    created = file
                    val out = ctx.contentResolver.openOutputStream(file.uri, "w")
                        ?: throw IOException("Cannot open file for writing")
                    out.use {
                        if (scrambleOffset == null) {
                            resp.body!!.byteStream().copyTo(it)
                        } else {
                            val bytes = resp.body!!.bytes()
                            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                ?: throw IOException("Could not decode a MangaFire page image")
                            val transformed = MangaFirePageTransform.unscramble(bitmap, scrambleOffset)
                            if (!transformed.compress(Bitmap.CompressFormat.JPEG, 95, it)) {
                                throw IOException("Could not save the decoded MangaFire page image")
                            }
                            if (transformed !== bitmap) transformed.recycle()
                            bitmap.recycle()
                        }
                    }
                }
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (isCancelled(chapterId)) throw CancellationException("Download canceled")
                lastError = e
                created?.delete()
                delay(1000L * (attempt + 1))
            } finally {
                call?.let { finished ->
                    synchronized(this) {
                        activeCalls[chapterId]?.let { calls ->
                            calls.remove(finished)
                            if (calls.isEmpty()) activeCalls.remove(chapterId)
                        }
                    }
                }
            }
        }
        throw lastError ?: IOException("Download failed")
    }

    private suspend fun awaitIfResumed(chapterId: Long) {
        while (true) {
            val gate = synchronized(this) { pauseGates[chapterId] } ?: break
            gate.await()
        }
        if (isCancelled(chapterId)) throw CancellationException("Download canceled")
        currentCoroutineContext().ensureActive()
    }

    private fun isCancelled(chapterId: Long): Boolean =
        synchronized(this) { chapterId in cancelledChapterIds }

    suspend fun deleteDownload(manga: MangaEntity, chapter: ChapterEntity) {
        val dir = ctx.app.storage.chapterDir(manga, chapter, create = false)
        if (dir != null && dir.exists() && !ctx.app.storage.deleteDownload(manga, chapter)) {
            throw IOException("Could not delete downloaded files for “${chapter.name}”")
        }
        ctx.app.db.chapterDao().setDownloaded(chapter.id, false)
    }
}
